# Spookie_Quiz_App
A simple quiz app using React and Typescript. It uses an APi from Opentdb for the quiz and a random number function for the quiz questions.
